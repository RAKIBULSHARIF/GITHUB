আমাদের ফাইনাল স্ক্রিপ্ট

http://nbviewer.jupyter.org/github/raqueeb/mltraining/blob/master/Python/titanic-project-test.ipynb

পুরানো স্ক্রিপ্ট 

http://nbviewer.jupyter.org/github/raqueeb/mltraining/blob/master/Python/titanic-project.ipynb


