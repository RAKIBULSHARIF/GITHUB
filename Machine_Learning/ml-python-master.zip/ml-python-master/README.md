# ml-python
ML with Python Book 
Python Scripts
https://raqueeb.gitbook.io/scikit-learn/
